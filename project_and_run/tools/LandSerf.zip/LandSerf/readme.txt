LandSerf 2.3.0 

This version of LandSerf 2.3 is not provided with a Java Runtime Environment and requires 
Java 1.5 or higher installed on your machine to work.

If you do not have a suitable version of Java installed on your machine, please download 
a free copy from http://www.java.com.

Full documentation can be found in the 'docs' folder and at www.landserf.org. It can also be
accessed by selecting the 'Help' menu item from within LandSerf.


---------------
Windows Release
---------------

To start Landserf, click on or type:

LandSerf.bat

in this folder (C:\Program Files\LandSerf).


-------------------------
Unix/Linux Release
-------------------------

To start Landserf open a shell window, and type

./landserf.sh


in this directory (C:\Program Files\LandSerf).

If you have large amounts of physical memory on your system, you can reallocate more of it
to LandSerf by editing landserf.sh and changing 1400 in the -Xmx1400m setting to an appropriate
figure (where 1400m refers to 1400 Mbytes).


Jo Wood
20th April, 2009

jwo@soi.city.ac.uk